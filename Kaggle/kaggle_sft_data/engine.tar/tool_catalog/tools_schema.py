"""
tools_schema.py
Catalogo Canonico Fechado (15 ferramentas densas) — 02 Diretrizes §2.
Espelho de data/tool_catalog/tools_schema.py para bundle Kaggle (06 §3).
"""

from typing import Dict, Any

TOOL_CATALOG: Dict[str, Dict[str, Any]] = {
    "bash": {
        "type": "function",
        "function": {
            "name": "bash",
            "description": "Executa comandos bash em terminal Linux e retorna stdout/stderr.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Linha de comando bash"}},
                "required": ["command"],
            },
        },
    },
    "powershell": {
        "type": "function",
        "function": {
            "name": "powershell",
            "description": "Administracao legitima Windows. Sem red team.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Comando PowerShell"}},
                "required": ["command"],
            },
        },
    },
    "read_file": {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Le arquivo local ou contexto de diretorio.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Caminho"}},
                "required": ["path"],
            },
        },
    },
    "write_file": {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Cria ou atualiza arquivo com conteudo.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Destino"},
                    "content": {"type": "string", "description": "Conteudo"},
                },
                "required": ["path", "content"],
            },
        },
    },
    "list_dir": {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "Lista conteudo estruturado de diretorio.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Diretorio"},
                    "recursive": {"type": "boolean", "description": "Recursiva"},
                },
                "required": ["path"],
            },
        },
    },
    "search_code": {
        "type": "function",
        "function": {
            "name": "search_code",
            "description": "Busca literal ou semantica no codigo.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Termo"},
                    "path": {"type": "string", "description": "Escopo"},
                },
                "required": ["query"],
            },
        },
    },
    "execute_command": {
        "type": "function",
        "function": {
            "name": "execute_command",
            "description": "Executa comando em sandbox local.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Comando"}},
                "required": ["command"],
            },
        },
    },
    "core_memory_append": {
        "type": "function",
        "function": {
            "name": "core_memory_append",
            "description": "Adiciona chave na memoria curta.",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "Chave"},
                    "value": {"type": "string", "description": "Valor"},
                },
                "required": ["key", "value"],
            },
        },
    },
    "core_memory_replace": {
        "type": "function",
        "function": {
            "name": "core_memory_replace",
            "description": "Atualiza chave existente.",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "Chave"},
                    "value": {"type": "string", "description": "Novo valor"},
                },
                "required": ["key", "value"],
            },
        },
    },
    "archival_memory_insert": {
        "type": "function",
        "function": {
            "name": "archival_memory_insert",
            "description": "Insere no longo prazo.",
            "parameters": {
                "type": "object",
                "properties": {"content": {"type": "string", "description": "Conteudo"}},
                "required": ["content"],
            },
        },
    },
    "archival_memory_search": {
        "type": "function",
        "function": {
            "name": "archival_memory_search",
            "description": "Recupera contexto por busca. Args vazio {} = varredura completa.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "Consulta (omitivel)"}},
                "required": [],
            },
        },
    },
    "python_interpreter": {
        "type": "function",
        "function": {
            "name": "python_interpreter",
            "description": "Executa Python em sandbox e retorna stdout.",
            "parameters": {
                "type": "object",
                "properties": {"code": {"type": "string", "description": "Codigo Python"}},
                "required": ["code"],
            },
        },
    },
    "calculator": {
        "type": "function",
        "function": {
            "name": "calculator",
            "description": "Avalia formula matematica.",
            "parameters": {
                "type": "object",
                "properties": {"expression": {"type": "string", "description": "Expressao"}},
                "required": ["expression"],
            },
        },
    },
    "http_request": {
        "type": "function",
        "function": {
            "name": "http_request",
            "description": "Chama endpoint REST.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "URL"},
                    "method": {"type": "string", "description": "GET ou POST"},
                },
                "required": ["url"],
            },
        },
    },
    "database_query": {
        "type": "function",
        "function": {
            "name": "database_query",
            "description": "SELECT somente-leitura.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "SQL SELECT"}},
                "required": ["query"],
            },
        },
    },
}

DOMAINS = {
    "terminal": ["bash", "powershell"],
    "workspace": ["read_file", "write_file", "list_dir", "search_code", "execute_command"],
    "memory": ["core_memory_append", "core_memory_replace", "archival_memory_insert", "archival_memory_search"],
    "technical": ["python_interpreter", "calculator", "http_request", "database_query"],
}
